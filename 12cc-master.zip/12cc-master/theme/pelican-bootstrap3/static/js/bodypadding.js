$(document).ready(function(){
    $('body').css('padding-top', $('.navbar').height()+'px');
});